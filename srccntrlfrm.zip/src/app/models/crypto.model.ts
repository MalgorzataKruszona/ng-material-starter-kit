export interface CryptoModel {
  readonly symbol: string;
  readonly lastPrice: string;
  readonly lastQty: string
}
