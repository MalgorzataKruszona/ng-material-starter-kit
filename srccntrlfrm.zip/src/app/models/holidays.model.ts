export interface HolidaysModel {
  readonly date: string;
  readonly localName: string;
  readonly name: string;
}
