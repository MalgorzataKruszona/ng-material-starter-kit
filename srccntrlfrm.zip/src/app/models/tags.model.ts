export interface TagsModel {
  readonly name: string;
  readonly id: string;
  readonly title: string;
  readonly description: string;
  readonly jobTagIds: string
}
