export interface FollowersModel {readonly followedBy:  [{readonly name: string}]
}
